# スクリプト名: ResizeAndCreatePartition.ps1
# このスクリプトは、Cドライブを指定サイズに縮小し、新しいパーティションを作成します。
# 管理者権限が必要です。

# 管理者権限チェック
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "このスクリプトは管理者権限で実行する必要があります。" -ForegroundColor Red
    Start-Process powershell -ArgumentList ("-File `"" + $PSCommandPath + "`"") -Verb RunAs
    Exit
}

# ユーザー入力または引数で縮小後のサイズ（GB）を指定
param (
    [int]$NewSizeGB
)

if (-not $NewSizeGB) {
    # ユーザーに対話形式でサイズを尋ねる
    $NewSizeGB = Read-Host "Cドライブの縮小後のサイズ（GB単位）を入力してください"
}

# 入力値チェック
if ($NewSizeGB -le 0) {
    Write-Host "無効なサイズが指定されました。" -ForegroundColor Red
    Exit
}

# GBをMBに変換し、1MBを追加する
$NewSizeMB = ($NewSizeGB * 1024) + 1

# 現在のCドライブの情報取得
$CDrive = Get-Partition -DriveLetter C
$CDriveSizeGB = [math]::Round($CDrive.Size / 1GB)
$CDriveSizeMB = [math]::Round($CDrive.Size / 1MB)

Write-Host "現在のCドライブのサイズ: $CDriveSizeGB GB ($CDriveSizeMB MB)"

if ($NewSizeMB -ge $CDriveSizeMB) {
    Write-Host "指定されたサイズは現在のサイズよりも大きいか同じです。縮小できません。" -ForegroundColor Red
    Exit
}

# 縮小するサイズを計算 (現在のサイズ - 指定されたサイズ)
$ShrinkSizeMB = $CDriveSizeMB - $NewSizeMB

# Cドライブのパーティションを縮小
Write-Host "Cドライブを $NewSizeGB GB に縮小します（$NewSizeMB MBに変換）。"
Resize-Partition -DriveLetter C -Size ($NewSizeMB * 1MB)

# Cドライブの後にできた空き領域のサイズを確認
$Disk = Get-Disk | Where-Object { $_.Partitions[0].DriveLetter -eq 'C' }
$FreeSpace = ($Disk | Get-PartitionSupportedSize -Partition (Get-Partition -DriveLetter C)).SizeMax

if ($FreeSpace -le 0) {
    Write-Host "空き領域がありません。操作を中止します。" -ForegroundColor Red
    Exit
}

# 新しいパーティション作成
Write-Host "空いたスペース ($($FreeSpace / 1MB) MB) に新しいパーティションを作成します..."
$NewPartition = New-Partition -DiskNumber $Disk.Number -Size $FreeSpace -AssignDriveLetter

# パーティションをNTFSでフォーマット
Write-Host "新しいパーティションをフォーマットします..."
Format-Volume -Partition $NewPartition -FileSystem NTFS -NewFileSystemLabel "NewPartition"

Write-Host "処理が完了しました。"
